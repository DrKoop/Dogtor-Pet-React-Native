import React, { useState } from 'react';
import {
  Alert,
  SafeAreaView,
  View,
  Text,
  StyleSheet,
  Button,
  Pressable,
  Modal,
  FlatList
} from 'react-native';
import Formulario from './src/components/Formulario';
import Paciente from './src/components/Paciente';
import InformacionPaciente from './src/components/InformacionPaciente';


const App = () => {
  //Zona Hooks, siempre parte superior 
  const [ modalVisible, setModalVisible ] = useState(false)
  const [ pacientes, setPacientes] = useState([])
  const [ paciente, setPaciente] = useState({})
  const [ modalPaciente, setModalPaciente ] = useState(false)

  const pacienteEditar = id => {
      //console.log(' editando', id)
      const pacienteEditar = pacientes.filter(paciente => paciente.id === id)
      //console.log('Test Editando' , pacienteEditar[0])
      setPaciente(pacienteEditar[0])
  }

  const pacienteEliminar = id => {
    //console.log('eliminanado' , id)
      Alert.alert(
          '¿Deseas elimiar este paciente?',
          'Este dato no se podra recuperar',
          [
            {text : 'Cancelar'},
            { text : 'Eliminar', onPress: () =>{
              //console.log('eliminando...')
              const pacientesActualizados = pacientes.filter( pacientesState => pacientesState.id !== id )
              //console.log(pacientesActualizados)
              setPacientes(pacientesActualizados)
            }}
          ]
      )
  }

  const cerrarModal = () => {
    setModalVisible(false)
  }

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.titulo}>Administrador de Citas {''}
        <Text style={styles.tituloBold}>Veterinaria</Text>
      </Text>

      <Pressable
        style={styles.btnNuevaCita}
        onPress={ () => setModalVisible(!modalVisible) }
      >
        <Text
          style={styles.btnTextoNuevaCita}
        >Nueva Cita</Text>
      </Pressable>

      {pacientes.length === 0 ? <Text style={styles.noPacientes}>No se han Registrado Pacientes aún</Text> : 
        <FlatList
          style={styles.listado}
          data={pacientes}
          //React.N Accede a cada id, proveniente del Date.now() del Modal-formulario
          keyExtractor={ (item) => item.id }
          //Render muestra el resultado de cada iteracion
          renderItem={({item}) => {
            return(
              <Paciente
                item={item}
                setModalVisible = { setModalVisible }
                setPaciente={ setPaciente }
                pacienteEditar = { pacienteEditar }
                pacienteEliminar = { pacienteEliminar }
                setModalPaciente = { setModalPaciente }
              />
            )
          }}
        />  
      }


      {/* El formulario como no esta dentro de otro componenet, no tiene un condicional que lo desmonte a diferencial de "Modal", el colocarle dicho condicional, obliga a purgar y vaciar todo el formulario para su correcta funcion */}
      {modalVisible && (
          <Formulario
          /* Variable a la izquiereda - Funcion a la Derecha  */
          /* modalVisible ={ modalVisible }
          setModalVisible = { setModalVisible } */
          cerrarModal= {cerrarModal}
          setPacientes={ setPacientes}
          pacientes= { pacientes }
          paciente = { paciente }
          setPaciente = { setPaciente }
        />
      )}


      <Modal
        visible={modalPaciente}
        animationType='fade'
      >
        <InformacionPaciente
          paciente = { paciente }
          setModalPaciente= {setModalPaciente}
          setPaciente = { setPaciente }
        />
      </Modal>

    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container:{
    backgroundColor: '#F3F4F6',
    flex: 1
  },
  titulo:{
    textAlign: 'center',
    fontSize: 30,
    color: '#374151',
    fontWeight: '600'
  },
  tituloBold: {
    fontWeight: '900',
    color: '#6D28D9',
  },
  btnNuevaCita: {
    backgroundColor: '#6D28D9',
    padding: 15,
    marginTop: 20,
    marginHorizontal: 20,
    borderRadius: 10
  },  
  btnTextoNuevaCita:{
    textAlign: 'center',
    color: '#FFF',
    fontSize: 18,
    fontWeight: '900',
    textTransform: 'uppercase'
  },
  noPacientes:{
    marginTop: 40,
    textAlign: 'center',
    fontSize: 18,
    fontWeight: '600'
  },
  listado:{
    marginTop: 50,
    marginHorizontal: 30
  }
})

export default App;
