import React, { useState, useEffect } from 'react'
import { 
  Alert,
  Modal,
  Text, 
  TextInput,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  View
} from 'react-native'

import DatePicker from 'react-native-date-picker'
import Pressable from 'react-native/Libraries/Components/Pressable/Pressable'

const Formulario = ({ 
   /* modalVisible,
   setModalVisible, */
   modalVisible,
   cerrarModal,
   pacientes,
   setPacientes,
   paciente: pacienteObj,
   setPaciente:  setPacienteApp }) => {
 //Zona Hooks, siempre parte superior
 /* Registrando campos */
 const [id, setId ]= useState('')
 const [paciente, setPaciente ] = useState('')
 const [propietario, setPropietario ] = useState('')
 const [email, setEmail ] = useState('')
 const [telefono, setTelefono ] = useState('')
 const [fecha, setFecha ] = useState(new Date())
 const [sintomas, setSintomas ] = useState('')


 useEffect(() => {
    if(Object.keys(pacienteObj).length > 0){
       setId(pacienteObj.id)
       setPaciente(pacienteObj.paciente)
       setPropietario(pacienteObj.propietario)
       setEmail(pacienteObj.email)
       setTelefono(pacienteObj.telefono)
       setFecha(pacienteObj.fecha)
       setSintomas(pacienteObj.sintomas)
    }
 }, [pacienteObj])

 const handleCita = () => {
    //Validar que todos los campos no esten vacios
    if([
        paciente,
        propietario,
        email,
        telefono,
        fecha,
        sintomas
      ].includes('')){
        //console.log('Todos los campos son obl...')
        //Alert toma 3 argumentos
        Alert.alert(
          'Campos Vacíos',
          'Todos los campos son obligatorios',
          [{text: 'Cancelar'}, {text: 'Regresar'}]
        )
        return
    }
    //Revisar si es un registro nuevo o edicion 

    const nuevoPaciente = {
      paciente,
      propietario,
      email,
      telefono,
      fecha,
      sintomas
    }
    
    if(id){
      //Editar Registro
      nuevoPaciente.id = id
      //console.log('test',nuevoPaciente)
      const pacientesActualizados = pacientes.map( pacienteState => pacienteState.id === nuevoPaciente.id ? nuevoPaciente : pacienteState )
      //console.log(pacientesActualizados)
      //return
      setPacientes(pacientesActualizados)
      setPacienteApp({})

    }else{
      //Nuevo Registro
      nuevoPaciente.id = Date.now()
      setPacientes([...pacientes, nuevoPaciente])
    }
    //console.log(nuevoPaciente)
    //setPacientes(nuevoPaciente)
    
    /* setModalVisible(!modalVisible) */
    cerrarModal()
    //Resetear state para evitar campos duplicados con la informacion anterior
    setId('')
    setPaciente('')
    setPropietario('')
    setEmail('')
    setTelefono('')
    setFecha(new Date())
    setSintomas('')
 }
 // {''} = Significa un espacio en blanco entre componentes
  return (
    <Modal
        animationType='slide'
        visible={ modalVisible }
    >
    <SafeAreaView style={ styles.contenido}>
      <ScrollView>
          <Text
            style={ styles.titulo}
          >{pacienteObj.id ? 'Editar' : 'Nueva'} {''}
            <Text
              style={ styles.tituloBold}
            >Cita</Text>
          </Text>

          <Pressable 
            style={styles.btnCancelar}
            onLongPress={() => {
              /* setModalVisible(!modalVisible) */
              cerrarModal()
              setPacienteApp({})
              setId('')
              setPaciente('')
              setPropietario('')
              setEmail('')
              setTelefono('')
              setFecha(new Date())
              setSintomas('')
            } }
          >
            <Text style={styles.btnCancelarTexto} >X Cancelar</Text>
          </Pressable>

          <View style={styles.campo} >
            <Text style={styles.label} >Nombre Paciente</Text>
            <TextInput
              style={styles.input}
              placeholder='Nombre Paciente'
              placeholderTextColor={'#666'}
              value={paciente}
              onChangeText={setPaciente}
            />
          </View>

          <View style={styles.campo} >
            <Text style={styles.label} >Nombre Propietario</Text>
            <TextInput
              style={styles.input}
              placeholder='Nombre Propietario'
              placeholderTextColor={'#666'}
              value={propietario}
              onChangeText={setPropietario}
            />
          </View>

          <View style={styles.campo} >
            <Text style={styles.label} >Email</Text>
            <TextInput
              style={styles.input}
              placeholder='Email'
              placeholderTextColor={'#666'}
              keyboardType='email-address'
              value={email}
              onChangeText={setEmail}
            />
          </View>

          <View style={styles.campo} >
            <Text style={styles.label} >Teléfono Propietario</Text>
            <TextInput
              style={styles.input}
              placeholder='Teléfono Propietario'
              placeholderTextColor={'#666'}
              keyboardType= 'number-pad'
              value={telefono}
              onChangeText={setTelefono}
              maxLength={10}
            />
          </View>

          <View style={styles.campo} >
            <Text style={styles.label} >Fecha De Alta</Text>
              {/* El DatePicker, lo rodea un View, para poderle dar estilos CSS */}
              <View style={styles.fechaContenedor} >
              <DatePicker
              
                  date={ fecha }
                  locale= 'es'
                  //mode='time'
                  onDateChange={ (date)=> setFecha(date)}
              />
              </View>

          </View>

          <View style={styles.campo} >
            <Text style={styles.label} >Síntomas Paciente</Text>
            <TextInput
              style={[styles.input, styles.sintomasInput]}
              placeholder='Síntomas Paciente'
              placeholderTextColor={'#666'}
              value={sintomas}
              onChangeText={setSintomas}
              multiline= {true}
              numberOfLines ={4}
            />
          </View>

          <Pressable 
            style={styles.nuevaCita}
            onPress = { handleCita }
          >
            <Text style={styles.nuevaCitaTexto} >{pacienteObj.id ? 'Editar' : 'Agregar'} Paciente</Text>
          </Pressable>

      </ScrollView>
    </SafeAreaView>
  </Modal>
  )
}

const styles = StyleSheet.create({
  contenido:{
      backgroundColor: '#6D28D9',
      flex : 1,
  },  
  titulo: {
      fontSize: 30,
      fontWeight: '600',
      textAlign: 'center',
      marginTop: 30,
      color: '#FFF'
    },
    tituloBold:{
      fontWeight: '900'
    },
    campo:{
      marginTop: 10,
      marginHorizontal: 30
    },
    label:{
      color: '#FFF',
      marginBottom: 10,
      marginTop: 15,
      fontSize: 20,
      fontWeight: '600'
    },
    input: {
      backgroundColor: '#FFF',
      padding: 15,
      borderRadius: 10
    },
    sintomasInput:{
      height: 100
    },
    fechaContenedor:{
      backgroundColor: '#FFF',
      borderRadius: 30
    },
    btnCancelar:{
      marginVertical: 30,
      marginHorizontal: 30,
      backgroundColor: '#5827A4',
      padding: 15,
      borderRadius: 10,
      borderWidth: 1,
      borderColor: '#FFF'
    },
    btnCancelarTexto:{
      color: '#FFF',
      textAlign: 'center',
      fontWeight: '900',
      fontSize: 16,
      textTransform: 'uppercase'
    },
    nuevaCita:{
      marginVertical: 50,
      backgroundColor: '#F59E0B',
      paddingVertical: 15,
      marginHorizontal: 30,
      borderRadius: 10
    },
    nuevaCitaTexto:{
      textAlign: 'center',
      color: '#5827A4',
      textTransform: 'uppercase',
      fontWeight: '900'
    }
})

export default Formulario